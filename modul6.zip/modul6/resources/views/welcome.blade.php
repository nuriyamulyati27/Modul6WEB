@extends('master')
@section('title', 'Halaman Utama Portal Kabar Burung')
@section('body')
<h1>Portal Kabar Burung</h1>
<a href="/berita">Tabel Berita</a><br><br>
    @foreach (App\berita::all() as $berita)
    @if($berita->published=='yes')
    <a href = "/berita/">{{ $berita->judul }}</a> <br>
    <hr>
        {{ $berita->created_at->format('M d, Y') }}
    <hr><br>
        {{ $berita->isi }}<br><br>
    <hr><br><br>
    @endif
    @endforeach
</tbody>
</table>
@endsection