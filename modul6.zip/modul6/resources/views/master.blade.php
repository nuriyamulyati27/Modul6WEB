<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initialscale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
{{-- TITLE UNTUK HALAMAN --}}
<title>@yield('title')</title>
</head>
<body>
{{-- KONTEN HALAMAN --}}
@yield('body')
</body>
</html>