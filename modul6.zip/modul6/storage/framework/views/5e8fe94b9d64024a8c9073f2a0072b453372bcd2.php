
<?php $__env->startSection('title', 'Halaman Utama Portal - Kabar Burung'); ?>
<?php $__env->startSection('body'); ?>
<h1>Halaman Tambah Berita</h1>
<form action="/berita/tambah/store" method="POST">
<?php echo csrf_field(); ?>
<label for="judul">Judul : </label>
<input type="text" id="judul" name="judul">
<br>
<br>
<label for="isi">Isi : </label>
<textarea name="isi" id="isi" rows="5"></textarea>
<br>
<br>
<label for="published">Published : </label>
<select name="published" id="published">
<option value="yes">Yes</option>
<option value="no">No</option>
</select>
<br>
<br>
<button type="submit">Tambahkan</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\modul6\resources\views/tambah.blade.php ENDPATH**/ ?>