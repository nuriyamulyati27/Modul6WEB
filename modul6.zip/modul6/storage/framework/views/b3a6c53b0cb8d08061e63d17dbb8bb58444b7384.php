<?php $__env->startSection('title', 'Halaman Utama Portal Kabar Burung'); ?>
<?php $__env->startSection('body'); ?>
<h1>Portal Kabar Burung</h1>
<a href="/berita">Tabel Berita</a><br><br>
    <?php $__currentLoopData = App\berita::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($berita->published=='yes'): ?>
    <a href = "/berita/"><?php echo e($berita->judul); ?></a> <br>
    <hr>
        <?php echo e($berita->created_at->format('M d, Y')); ?>

    <hr><br>
        <?php echo e($berita->isi); ?><br><br>
    <hr><br><br>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\modul6\resources\views/welcome.blade.php ENDPATH**/ ?>