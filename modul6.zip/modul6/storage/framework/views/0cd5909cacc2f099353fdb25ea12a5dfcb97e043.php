
<?php $__env->startSection('title', 'Halaman Utama Portal - Kabar Burung'); ?>
<?php $__env->startSection('body'); ?>
<h1>Portal - Kabar Burung</h1>
<a href="/berita/tambah">Tambah Berita</a>
<table border="1">
<thead>
    <tr>
    <th>No</th>
    <th>Judul</th>
    <th>Published</th>
    <th>Tanggal</th>
    <th>Action</th>
    </tr>
</thead>
<tbody>
<?php $no=1 ?>

    <?php $__currentLoopData = App\berita::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($no++); ?></td>
    <td><?php echo e($berita->judul); ?></td>
    <td><?php echo e($berita->published); ?></td>
    <td><?php echo e($berita->created_at->diffForHumans()); ?></td> <!--keg1-->
    <td><a href = "/berita/<?php echo e($berita->id); ?>/deleted">Hapus</a></td> <!--keg2-->

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\modul6\resources\views/index.blade.php ENDPATH**/ ?>