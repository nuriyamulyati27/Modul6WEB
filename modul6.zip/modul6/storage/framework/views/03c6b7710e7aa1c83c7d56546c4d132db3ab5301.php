<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initialscale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">

<title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

<?php echo $__env->yieldContent('body'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\modul6\resources\views/master.blade.php ENDPATH**/ ?>